let userScore = 0;
let compScore = 0;
const userScore_span = document.getElementById('user-score');
const compScore_span = document.getElementById('computer-score');
const rock = document.getElementById('r');
const paper = document.getElementById('p');
const scissor = document.getElementById('s');
const result = document.querySelector('.result > p');

function main(){
rock.addEventListener("click",function() {
	usergame('r');
	
})

paper.addEventListener("click",function() {
	usergame('p');	
})

scissor.addEventListener("click",function() {
	usergame('s');

})
}
main();

function win(userchoise,computerchoise){
	userScore++;
	userScore_span.innerHTML = userScore;
	result.innerHTML = `You Put ${converttoword(usergame(userchoise)) } & Computer put ${converttoword(computerGame(computerchoise))}, YOU WIN!!`;
}

function lose(userchoise,computerchoise){
	compScore++;
	compScore_span.innerHTML = compScore;
	result.innerHTML = `You Put ${converttoword(userchoise) } & Computer put ${converttoword(computerchoise)}, Computer WINS!!`;
}

function draw(userchoise,computerchoise){
	result.innerHTML = `You and Computer both put ${converttoword(userchoise) }`;
}

function converttoword(letter){
	if(letter == 'r'){
		return 'Rock';
	}
	else if (letter == 'p') {
		return 'Paper';
	}
		return 'Scissor';
	}


function usergame(userchoise){
	const computerchoise = computerGame();
	switch(userchoise + computerchoise){
		case "rs" : 
		case "pr" :
		case "sp" :
		win();
	}

	switch(userchoise + computerchoise){
		case "sr" : 
		case "rp" :
		case "ps" :
		lose();
	}

	 switch(userchoise + computerchoise){
	 	case "ss" : 
	 	case "rr" :
	 	case "pp" :
	 	draw();
	
}
}

function computerGame() {
	const output = ['r','p','s'];
	const RandomSource = Math.floor(Math.random()*3);
	return  output[RandomSource];
	
}





